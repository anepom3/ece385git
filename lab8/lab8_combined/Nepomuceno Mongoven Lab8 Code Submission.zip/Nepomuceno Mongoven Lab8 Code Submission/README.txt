What works:
Keyboard successfully communicates with board and keycodes are correctly displayed on HEX LED Displays.
VGA monitor correctly displays the red ball and responds to keyboard directions.

Expected Demo Points: 5

Note:
When first booted up the keycode starts at 0x20 and the ball is in motion.

However, upon pressing Reset (KEY[0] button), the system is properly initialized with
keycode reading 0x00 on the HEX LED Displays and the ball begins stationary in the center
and behaves properly.